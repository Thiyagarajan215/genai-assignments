const form = document.querySelector(".review-form");
const repositoryInput = document.querySelector("#repository-url");
const submitButton = document.querySelector(".review-button");
const submitLabel = submitButton.querySelector("span");
const resultsCard = document.querySelector("#review-results");
const resultBadge = document.querySelector(".result-badge");

const requestTimeoutMs = 125_000;
const initialSubmitLabel = submitLabel.textContent;
const severityClasses = new Map([
  ["critical", "critical"],
  ["high", "high"],
  ["medium", "medium"],
  ["low", "low"],
  ["warning", "warning"],
  ["suggestion", "suggestion"],
  ["positive", "positive"],
  ["info", "info"],
]);
let focusSubmitOnComplete = false;

function setBadge(label, state) {
  resultBadge.lastChild.textContent = label;
  resultBadge.dataset.state = state;
}

function showMessage(message, state, { retry = false } = {}) {
  const content = document.createElement("p");
  content.className = "review-status";
  content.dataset.state = state;
  content.textContent = message;
  content.setAttribute("role", state === "error" ? "alert" : "status");

  const children = [content];
  if (retry) {
    const retryButton = document.createElement("button");
    retryButton.className = "retry-button";
    retryButton.type = "button";
    retryButton.textContent = "Try review again";
    retryButton.addEventListener("click", () => {
      focusSubmitOnComplete = true;
      form.requestSubmit();
    });
    children.push(retryButton);
  }

  resultsCard.replaceChildren(...children);
  resultsCard.setAttribute("aria-busy", "false");
}

function showLoading() {
  const indicator = document.createElement("span");
  indicator.className = "review-loading-indicator";
  indicator.setAttribute("aria-hidden", "true");

  const message = document.createElement("p");
  message.className = "review-status";
  message.dataset.state = "loading";
  message.setAttribute("role", "status");
  message.textContent = "Review in progress. Waiting for the repository review to finish…";

  resultsCard.replaceChildren(indicator, message);
  resultsCard.setAttribute("aria-busy", "true");
}

function appendInlineMarkdown(parent, text) {
  const inlinePattern = /(\*\*[^*]+\*\*|`[^`]+`)/g;
  const leadingSeverity = text.match(/^\s*\[?(critical|high|medium|low|warning|suggestion|positive|info)\]?\s*:\s*/i);
  let currentIndex = 0;

  if (leadingSeverity) {
    const badge = document.createElement("span");
    const severity = leadingSeverity[1].toLowerCase();
    badge.className = `severity-badge severity-${severityClasses.get(severity)}`;
    badge.textContent = leadingSeverity[1];
    parent.append(badge, document.createTextNode(" "));
    currentIndex = leadingSeverity[0].length;
  }

  for (const match of text.matchAll(inlinePattern)) {
    if (match.index < currentIndex) continue;
    parent.append(document.createTextNode(text.slice(currentIndex, match.index)));

    const token = match[0];
    let formatted;
    if (token.startsWith("**")) {
      const label = token.slice(2, -2);
      const severity = label.trim().replace(/:$/, "").toLowerCase();
      if (severityClasses.has(severity)) {
        formatted = document.createElement("span");
        formatted.className = `severity-badge severity-${severityClasses.get(severity)}`;
      } else {
        formatted = document.createElement("strong");
      }
      formatted.textContent = label;
    } else {
      formatted = document.createElement("code");
      formatted.textContent = token.slice(1, -1);
    }
    parent.append(formatted);
    currentIndex = match.index + token.length;
  }

  parent.append(document.createTextNode(text.slice(currentIndex)));
}

function splitMarkdownTableRow(line) {
  const row = line.trim().replace(/^\|/, "").replace(/\|$/, "");
  const cells = [];
  let cell = "";
  let insideCode = false;

  for (let index = 0; index < row.length; index += 1) {
    const character = row[index];
    if (character === "\\" && row[index + 1] === "|") {
      cell += "|";
      index += 1;
    } else if (character === "`") {
      insideCode = !insideCode;
      cell += character;
    } else if (character === "|" && !insideCode) {
      cells.push(cell.trim());
      cell = "";
    } else {
      cell += character;
    }
  }

  cells.push(cell.trim());
  return cells;
}

function getTableAlignment(delimiter) {
  const left = delimiter.startsWith(":");
  const right = delimiter.endsWith(":");
  if (left && right) return "center";
  if (right) return "right";
  return "left";
}

function createReviewTable(headers, alignments, rows) {
  const wrapper = document.createElement("div");
  wrapper.className = "review-table-wrap";

  const table = document.createElement("table");
  table.className = "review-table";

  const caption = document.createElement("caption");
  caption.className = "visually-hidden";
  caption.textContent = "Structured review findings";
  table.append(caption);

  const head = document.createElement("thead");
  const headerRow = document.createElement("tr");
  headers.forEach((header, index) => {
    const cell = document.createElement("th");
    cell.scope = "col";
    cell.style.textAlign = alignments[index];
    appendInlineMarkdown(cell, header);
    headerRow.append(cell);
  });
  head.append(headerRow);
  table.append(head);

  const body = document.createElement("tbody");
  rows.forEach((row) => {
    const tableRow = document.createElement("tr");
    headers.forEach((_, index) => {
      const cell = document.createElement("td");
      cell.style.textAlign = alignments[index];
      appendInlineMarkdown(cell, row[index] || "");
      tableRow.append(cell);
    });
    body.append(tableRow);
  });
  table.append(body);
  wrapper.append(table);
  return wrapper;
}

function renderReview(review) {
  const content = document.createElement("div");
  content.className = "review-content";
  const lines = review.replace(/\r\n?/g, "\n").split("\n");
  let paragraphLines = [];
  let list = null;
  let listType = null;
  let codeBlock = null;

  function flushParagraph() {
    if (paragraphLines.length === 0) return;

    const paragraph = document.createElement("p");
    appendInlineMarkdown(paragraph, paragraphLines.join(" "));
    content.append(paragraph);
    paragraphLines = [];
  }

  function endList() {
    list = null;
    listType = null;
  }

  for (let lineIndex = 0; lineIndex < lines.length; lineIndex += 1) {
    const line = lines[lineIndex];

    if (!codeBlock && lineIndex + 1 < lines.length) {
      const headers = splitMarkdownTableRow(line);
      const delimiters = splitMarkdownTableRow(lines[lineIndex + 1]);
      const isTableHeader = headers.length > 1 && line.includes("|");
      const isTableDelimiter = delimiters.length === headers.length
        && delimiters.every((delimiter) => /^:?-{3,}:?$/.test(delimiter));

      if (isTableHeader && isTableDelimiter) {
        flushParagraph();
        endList();
        const alignments = delimiters.map(getTableAlignment);
        const rows = [];
        let rowIndex = lineIndex + 2;
        while (rowIndex < lines.length && lines[rowIndex].trim() && lines[rowIndex].includes("|")) {
          const row = splitMarkdownTableRow(lines[rowIndex]);
          if (row.length < 2) break;
          rows.push(Array.from({ length: headers.length }, (_, index) => row[index] || ""));
          rowIndex += 1;
        }
        content.append(createReviewTable(headers, alignments, rows));
        lineIndex = rowIndex - 1;
        continue;
      }
    }

    if (line.trimStart().startsWith("```")) {
      flushParagraph();
      endList();
      if (codeBlock) {
        content.append(codeBlock);
        codeBlock = null;
      } else {
        codeBlock = document.createElement("pre");
        codeBlock.append(document.createElement("code"));
      }
      continue;
    }

    if (codeBlock) {
      codeBlock.querySelector("code").append(document.createTextNode(`${line}\n`));
      continue;
    }

    const heading = line.match(/^\s{0,3}(#{1,4})\s+(.+)$/);
    if (heading) {
      flushParagraph();
      endList();
      const element = document.createElement(heading[1].length <= 2 ? "h3" : "h4");
      appendInlineMarkdown(element, heading[2]);
      content.append(element);
      continue;
    }

    const listItem = line.match(/^\s*(?:([-*+])\s+|(\d+)[.)]\s+)(.+)$/);
    if (listItem) {
      flushParagraph();
      const nextListType = listItem[2] ? "ol" : "ul";
      if (!list || listType !== nextListType) {
        listType = nextListType;
        list = document.createElement(listType);
        if (listType === "ol" && Number(listItem[2]) > 1) {
          list.start = Number(listItem[2]);
        }
        content.append(list);
      }
      const item = document.createElement("li");
      appendInlineMarkdown(item, listItem[3]);
      list.append(item);
      continue;
    }

    if (!line.trim()) {
      flushParagraph();
      endList();
      continue;
    }

    endList();
    paragraphLines.push(line.trim());
  }

  flushParagraph();
  if (codeBlock) content.append(codeBlock);
  return content;
}

function validateRepositoryUrl(value) {
  let url;

  try {
    url = new URL(value);
  } catch {
    return false;
  }

  if (url.protocol !== "https:" || url.hostname !== "github.com" || url.username || url.password) {
    return false;
  }

  const segments = url.pathname.split("/").filter(Boolean);
  if (segments.length < 2 || !/^[A-Za-z0-9_.-]+$/.test(segments[0]) || !/^[A-Za-z0-9_.-]+$/.test(segments[1])) {
    return false;
  }

  if (segments.length === 2) {
    return true;
  }

  return (segments[2] === "tree" || segments[2] === "blob") && segments.length >= 4;
}

function getErrorMessage(status) {
  if (status === 400) {
    return "That URL is not supported. Use a GitHub repository URL or a folder/file URL under /tree/ or /blob/.";
  }
  if (status === 502) {
    return "The review service could not complete the request. Check the n8n workflow and confirm it can access this repository, then try again.";
  }
  if (status === 503) {
    return "The review service is not configured yet. Ask the site administrator to configure the n8n webhook.";
  }
  if (status === 504) {
    return "The review took too long to finish. Check the repository or workflow, then try again.";
  }
  return "The repository could not be reviewed. Check the URL and try again.";
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  const repositoryUrl = repositoryInput.value.trim();

  if (!repositoryUrl) {
    repositoryInput.setAttribute("aria-invalid", "true");
    setBadge("URL required", "error");
    showMessage("Paste a GitHub URL to start your review.", "error");
    repositoryInput.focus();
    return;
  }

  if (!validateRepositoryUrl(repositoryUrl)) {
    repositoryInput.setAttribute("aria-invalid", "true");
    setBadge("Check the URL", "error");
    showMessage(
      "Enter a supported GitHub URL, such as https://github.com/owner/repository or a /tree/ or /blob/ path.",
      "error",
    );
    repositoryInput.focus();
    return;
  }

  repositoryInput.removeAttribute("aria-invalid");
  submitButton.disabled = true;
  repositoryInput.disabled = true;
  submitButton.setAttribute("aria-busy", "true");
  submitLabel.textContent = "Reviewing…";
  setBadge("Review in progress", "loading");
  showLoading();

  const controller = new AbortController();
  const timeoutId = window.setTimeout(() => controller.abort(), requestTimeoutMs);

  try {
    const response = await fetch("/api/review", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ repositoryUrl }),
      signal: controller.signal,
    });

    const result = await response.json().catch(() => null);
    if (!response.ok) {
      setBadge("Review failed", "error");
      showMessage(result?.error || getErrorMessage(response.status), "error", { retry: true });
      return;
    }

    if (typeof result?.review !== "string" || !result.review.trim()) {
      setBadge("Review failed", "error");
      showMessage(
        "The review service returned no review text. Check the n8n response format and try again.",
        "error",
        { retry: true },
      );
      return;
    }

    const heading = document.createElement("h3");
    heading.textContent = "Review complete";
    heading.className = "review-complete-heading";

    const review = renderReview(result.review);

    resultsCard.replaceChildren(heading, review);
    resultsCard.setAttribute("aria-busy", "false");
    setBadge("Review complete", "success");
  } catch (error) {
    setBadge("Review failed", "error");
    if (error.name === "AbortError") {
      showMessage(
        "The review took too long to finish. Check the repository or workflow, then try again.",
        "error",
        { retry: true },
      );
    } else {
      showMessage("Could not reach the review service. Check your connection and try again.", "error", { retry: true });
    }
  } finally {
    window.clearTimeout(timeoutId);
    submitButton.disabled = false;
    submitButton.removeAttribute("aria-busy");
    submitLabel.textContent = initialSubmitLabel;
    repositoryInput.disabled = false;
    if (focusSubmitOnComplete) {
      focusSubmitOnComplete = false;
      submitButton.focus();
    }
  }
});

repositoryInput.addEventListener("input", () => {
  repositoryInput.removeAttribute("aria-invalid");
});
