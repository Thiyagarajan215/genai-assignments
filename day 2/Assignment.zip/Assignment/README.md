# AI GitHub Code Reviewer

## Run locally

Requires Node.js 20.6 or newer. The project loads a local `.env` file at startup. Copy `.env.example` to `.env`, set `N8N_WEBHOOK_URL` to your n8n webhook URL, then start the app:

```powershell
Copy-Item .env.example .env
# Edit .env and set N8N_WEBHOOK_URL to your webhook URL.
npm start
```

The local `.env` file is ignored by Git. Environment variables already set in the process take precedence over values in `.env`. Open <http://127.0.0.1:3000>. `PORT` can be set to use another port. The server binds to localhost by default; set `HOST` when deploying behind a trusted reverse proxy. Never put a real webhook URL in browser code or commit it to source control.

## n8n workflow contract

The webhook URL is configured in `.env` and kept server-side. The n8n workflow must use this request/response contract:

- The server sends an HTTP `POST` with `Content-Type: application/json` and body `{"repositoryUrl":"https://github.com/owner/repository"}`. Folder and file links under `/tree/` and `/blob/` are also accepted.
- On success, the webhook returns a 2xx status and a JSON object with a non-empty string property named `review`, for example `{"review":"Review text returned by the workflow."}`.
- The `review` string may contain Markdown tables. The page renders those as horizontally scrollable, accessible tables; other review text continues to render as text and supported Markdown without changing the response contract.
- A non-2xx webhook response, invalid JSON, or a missing/empty `review` string is treated as a failed review. The app does not fabricate findings or reinterpret other response fields.
- The server times out webhook requests after two minutes. Public repositories are supported only if the workflow can access them; private repository authentication must be handled securely in the backend.

The browser calls the same-origin `/api/review` endpoint. The server reads `N8N_WEBHOOK_URL` from its environment and proxies the request, so the webhook URL is not sent to the browser. For a `localhost` webhook, the app server and n8n must share the same network namespace; if they run in separate containers, use a hostname reachable between those containers instead.
