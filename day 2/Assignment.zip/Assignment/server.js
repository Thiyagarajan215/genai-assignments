const http = require("node:http");
const fs = require("node:fs");
const path = require("node:path");

const rootDirectory = __dirname;
const host = process.env.HOST || "127.0.0.1";
const port = Number(process.env.PORT || 3000);
const webhookTimeoutMs = 120_000;
const maxRequestBytes = 16_384;
const mimeTypes = {
  ".css": "text/css; charset=utf-8",
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
};
const publicFiles = new Map([
  ["/", "index.html"],
  ["/index.html", "index.html"],
  ["/styles.css", "styles.css"],
  ["/app.js", "app.js"],
]);

function sendJson(response, statusCode, data) {
  response.writeHead(statusCode, {
    "Cache-Control": "no-store",
    "Content-Type": "application/json; charset=utf-8",
    "X-Content-Type-Options": "nosniff",
  });
  response.end(JSON.stringify(data));
}

function parseWebhookUrl() {
  const configuredUrl = process.env.N8N_WEBHOOK_URL;
  if (!configuredUrl) {
    return null;
  }

  let webhookUrl;
  try {
    webhookUrl = new URL(configuredUrl);
  } catch {
    throw new Error("N8N_WEBHOOK_URL must be a valid HTTP or HTTPS URL.");
  }

  if (webhookUrl.protocol !== "https:" && webhookUrl.protocol !== "http:") {
    throw new Error("N8N_WEBHOOK_URL must use HTTP or HTTPS.");
  }

  return webhookUrl;
}

async function handleReview(request, response) {
  const { body, bodyTooLarge } = await readRequestBody(request);

  if (bodyTooLarge) {
    sendJson(response, 413, { error: "The request was too large." });
    return;
  }

  let payload;
  try {
    payload = JSON.parse(body);
  } catch {
    sendJson(response, 400, { error: "The review request must contain valid JSON." });
    return;
  }

  if (!payload || typeof payload.repositoryUrl !== "string" || !isSupportedGitHubUrl(payload.repositoryUrl)) {
    sendJson(response, 400, { error: "Enter a supported GitHub repository URL." });
    return;
  }

  let webhookUrl;
  try {
    webhookUrl = parseWebhookUrl();
  } catch (error) {
    console.error(error.message);
    sendJson(response, 503, { error: "The review service is not configured correctly." });
    return;
  }

  if (!webhookUrl) {
    sendJson(response, 503, { error: "The n8n webhook has not been configured." });
    return;
  }

  let webhookResponse;
  try {
    webhookResponse = await fetch(webhookUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify({ repositoryUrl: payload.repositoryUrl }),
      redirect: "error",
      signal: AbortSignal.timeout(webhookTimeoutMs),
    });
  } catch (error) {
    if (error.name === "TimeoutError" || error.name === "AbortError") {
      sendJson(response, 504, { error: "The repository review timed out." });
      return;
    }

    sendJson(response, 502, { error: "The review service could not be reached." });
    return;
  }

  if (!webhookResponse.ok) {
    sendJson(response, 502, { error: "The review service returned an unsuccessful response." });
    return;
  }

  let result;
  try {
    result = await webhookResponse.json();
  } catch {
    sendJson(response, 502, { error: "The review service returned an invalid response." });
    return;
  }

  if (!result || typeof result.review !== "string" || !result.review.trim()) {
    sendJson(response, 502, { error: "The review service response must contain a non-empty review string." });
    return;
  }

  sendJson(response, 200, { review: result.review });
}

function readRequestBody(request) {
  return new Promise((resolve, reject) => {
    let size = 0;
    let bodyTooLarge = false;
    const chunks = [];

    request.on("data", (chunk) => {
      size += chunk.length;
      if (size > maxRequestBytes) {
        bodyTooLarge = true;
        chunks.length = 0;
        return;
      }

      if (!bodyTooLarge) {
        chunks.push(chunk);
      }
    });
    request.on("end", () => {
      resolve({
        body: bodyTooLarge ? "" : Buffer.concat(chunks).toString("utf8"),
        bodyTooLarge,
      });
    });
    request.on("error", reject);
  });
}

function isSupportedGitHubUrl(value) {
  let url;
  try {
    url = new URL(value);
  } catch {
    return false;
  }

  if (url.protocol !== "https:" || url.hostname !== "github.com" || url.username || url.password) {
    return false;
  }

  const segments = url.pathname.split("/").filter(Boolean);
  if (segments.length < 2 || !/^[A-Za-z0-9_.-]+$/.test(segments[0]) || !/^[A-Za-z0-9_.-]+$/.test(segments[1])) {
    return false;
  }

  return segments.length === 2 || ((segments[2] === "tree" || segments[2] === "blob") && segments.length >= 4);
}

const server = http.createServer(async (request, response) => {
  const pathname = new URL(request.url, "http://localhost").pathname;

  if (pathname === "/api/review") {
    if (request.method !== "POST") {
      response.setHeader("Allow", "POST");
      sendJson(response, 405, { error: "Use POST to submit a repository for review." });
      return;
    }

    if (!request.headers["content-type"]?.includes("application/json")) {
      sendJson(response, 415, { error: "The review request must use JSON." });
      return;
    }

    response.setTimeout(webhookTimeoutMs + 5_000, () => {
      if (!response.headersSent) {
        sendJson(response, 504, { error: "The repository review timed out." });
      }
    });
    try {
      await handleReview(request, response);
    } catch {
      console.error("Failed to process a repository review request.");
      if (!response.headersSent) {
        sendJson(response, 500, { error: "The review request could not be processed." });
      } else {
        response.destroy();
      }
    }
    return;
  }

  if (request.method !== "GET" && request.method !== "HEAD") {
    response.writeHead(405, { Allow: "GET, HEAD" });
    response.end();
    return;
  }

  const fileName = publicFiles.get(pathname);
  if (!fileName) {
    response.writeHead(404);
    response.end("Not found");
    return;
  }

  const filePath = path.join(rootDirectory, fileName);
  fs.readFile(filePath, (error, contents) => {
    if (error) {
      console.error(`Could not read ${fileName}: ${error.message}`);
      response.writeHead(500);
      response.end("Unable to serve the application.");
      return;
    }

    response.writeHead(200, {
      "Cache-Control": "no-cache",
      "Content-Type": mimeTypes[path.extname(fileName)],
      "X-Content-Type-Options": "nosniff",
    });
    response.end(request.method === "HEAD" ? undefined : contents);
  });
});

server.listen(port, host, () => {
  console.log(`AI GitHub Code Reviewer is running at http://${host}:${port}`);
});
